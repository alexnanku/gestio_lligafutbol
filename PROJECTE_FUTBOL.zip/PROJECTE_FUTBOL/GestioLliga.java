package PROJECTE_FUTBOL;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;

public class GestioLliga {

    static Scanner sc = new Scanner(System.in);
    static String teampath = "C:\\Users\\haze9\\Desktop\\DAM\\M3 Programació\\Projecte_futbol\\PROJECTE_FUTBOL\\files\\lliga_esportiva\\equips.txt";
    static boolean exit;

    public static String[] equips = new String[10];
    public static int[][] punts = new int[100][100];

    // Fico els contadors per fer-los servir per imprimir la informació.
    static int countEquips = 0;
    static int countPunts = 0;

    // Inicio un conjunt de valors per poder fer calculs amb ells desprès.
    static String nomEquip;
    static int pJugats;
    static int pGuanyats;
    static int pPerduts;
    static int pEmpatats;
    static int pTotals;

    public static void main(String[] args) {

        try {
            startup();
            menu();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    static void startup() throws IOException, FileNotFoundException {

        // Creo un File reader per poder llegir el fitxer designat a la ruta del meu
        // string "teampath".
        // El while, mentres el fitxer tingui linies, estarà llegin en bucle.
        File file = new File(teampath);
        Scanner lector;
        FileReader reader = new FileReader(file);
        // Tanco el buffer en try per que no hi hagi un leak en el buffer en si.
        try (BufferedReader buffer = new BufferedReader(reader)) {
        }
        try {
            lector = new Scanner(file);
            while (lector.hasNextLine()) {
                String linea = lector.nextLine();
                try (Scanner sc = new Scanner(linea)) {
                    // He tingut varios problemes amb el delimiter ja que no funcione amb "|" que es
                    // lo que feia servir avans i he tingut molts problemes per donar-me compte ja
                    // que tot el rato me donave el error de mismatch exception en milers de linies
                    // amb el scanner.
                    sc.useDelimiter(":");
                    System.out.println();
                    System.out.print(equips[countEquips++] = sc.next());
                    System.out.println();
                    System.out.print("Partits jugats: \t");

                    System.out.print(punts[countPunts][1] = sc.nextInt());
                    System.out.println();
                    System.out.print("Partits guanyats: \t");

                    System.out.print(punts[countPunts][2] = sc.nextInt());
                    System.out.println();
                    System.out.print("Partits perduts: \t");

                    System.out.print(punts[countPunts][3] = sc.nextInt());
                    System.out.println();
                    System.out.print("Partits empatats: \t");

                    System.out.print(punts[countPunts][4] = sc.nextInt());
                    System.out.println();
                    System.out.print("Puntuació total: \t");

                    System.out.print(punts[countPunts][5] = sc.nextInt());
                    System.out.println();
                }
                countPunts++;
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    // Un mètode que he intentat varies vegades, nomès l'he comentat.
    // private static void lecturaFitxer(File file) throws FileNotFoundException {

    // System.out.println("Equips amb les seves puntuacions al fitxer: ");

    // try (Scanner lector = new Scanner(file)) {
    // while (lector.hasNextLine()) {
    // int idx = 0;
    // System.out.println(lector.nextLine());

    // String dEquips = lector.nextLine();

    // int sepEquips = dEquips.indexOf("|");

    // String nomEquip = dEquips.substring(0, sepEquips);
    // equips[idx] = nomEquip;
    // idx++;
    // lector.nextLine();
    // }
    // lector.close();
    // } catch (Exception e) {
    // System.out.println("No s'ha pogut llegir el fitxer :(");
    // // TODO: handle exception
    // }
    // System.out.println(equips[1]);
    // }

    static void menu() throws IOException {

        // Simple menú fet amb switch en el que crido cada mètode.
        do {
            System.out.println("***********************Gestió Lliga Esportiva***********************");
            System.out.println("1. Visualitzar els equips actuals.");
            System.out.println("2. Afegir un equip nou.");
            System.out.println("5. Sortir de la aplicació.");

            int opcio = sc.nextInt();

            switch (opcio) {

                case 1:
                    veurePuntuacions();
                    break;
                case 2:
                    afegirEquip();
                    break;
                case 3:
                    modificacioEquip();
                    break;
                case 4:
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Opció incorrecta.");
            }
        } while (!exit);
    }

    static void veurePuntuacions() throws IOException, FileNotFoundException {

        File fitxer = new File(teampath);
        FileReader reader = new FileReader(fitxer);
        // Per a que no hi hagi leak el tanco en try resource.
        try (BufferedReader buffer = new BufferedReader(reader)) {
        }

        for (int i = 0; i < equips.length; i++) {
            // Mentres el array de equips no sigui null, imprimirà els prints. Ho fem per a
            // que no comenci a imprimir totes les posicions nulls que tenim al array en
            // consola.
            if (equips[i] != null) {
                System.out.println("Equip: " + equips[i]);
                System.out.println("Partits jugats: " + punts[i][1] + "\t Partits guanyats: " + punts[i][2]
                        + "\t Partits perduts: " + punts[i][3] + "\t Partits empatats: " + punts[i][4]
                        + "\nPuntuació total: " + punts[i][5]);
                System.out.println();
            }
        }
    }

    static void afegirEquip() throws FileNotFoundException, IOException {
        int j;
        File fitxer = new File(teampath);
        FileWriter fw = new FileWriter(fitxer, true);
        Scanner teclat = new Scanner(System.in);
        for (int i = countEquips; i < equips.length; i++) {
            if (equips[i] == null) {
                j = i;

                System.out.println("Introdueix el nom del equip que vols afegir.");
                nomEquip = teclat.nextLine();
                equips[j] = nomEquip;

                System.out.println("Introdueix els partits jugats.");
                pJugats = teclat.nextInt();
                punts[i][1] = pJugats;

                System.out.println("Introdueix els partits guanyats.");
                pGuanyats = teclat.nextInt();
                punts[i][2] = pGuanyats;

                System.out.println("Introdueix els partits perduts.");
                pPerduts = teclat.nextInt();
                punts[i][3] = pPerduts;

                System.out.println("Introdueix els partits empatats.");
                pEmpatats = teclat.nextInt();
                punts[i][4] = pEmpatats;

                pTotals = pGuanyats * 3 + pEmpatats * 1 + (pPerduts * 0);
                punts[i][5] = pTotals;

                fw.write(
                        "\n" + equips[i] + ":" + punts[i][1] + ":" + punts[i][2] + ":" + punts[i][3] + ":" + punts[i][4]
                                + ":" + pTotals);
                fw.close();
                break;
            }
        }
    }

    static void modificacioEquip() throws IOException, FileNotFoundException {
        
        int x = 0;
        File file = new File(teampath);
        FileReader reader = new FileReader(file);
        BufferedReader buffer = new BufferedReader(reader);
        Scanner teclat = new Scanner(System.in);

        System.out.println("Quin equip vols modificar");
        nomEquip = teclat.nextLine();
        for (int i = 0; i < Equips.length; i++) {
            if (Equips[i] != null) {
                x = i;
            }
            
            if (equips[x].equals(nomEquip)) {
                do {
                    System.out.println("Introdueix la modificacio desitjada: ");
                    System.out.println("1. Puntuació");
                    System.out.println("2. Nom");
                    System.out.println("3. Partits jugats");
                    System.out.println("4. Partits guanyats");
                    System.out.println("5. Partits empatats");
                    System.out.println("6. Partits perduts");
                    System.out.println("7. Sortir");
                    
                    Scanner sc = new Scanner(System.in);
                    String sa = sc.next();
                    int opcio = sc.nextInt();
                    
                    switch (opcio) {
                        case 1:
                            if (equips[x].equals(nomEquip)) {
                                System.out.println("Puntuació total");
                                Puntuacions[i][5] = teclat.nextInt();
                            }
                        case 2:
                            if (equips[x].equals(nomEquip)) {
                                System.out.println("Nou Nom");
                                equips[x] = teclat.nextLine();
                                break;
                            }
                        case 3:
                            if (equips[x].equals(nomEquip)) {
                                System.out.println("");
                                Puntuacions[i][1] = teclat.nextInt();
                                Puntuacions[i][5] = (Puntuacions[i][2] * 3 + Puntuacions[i][3] * 1);
                                break;
                            }
                        case 4:
                            if (equips[x].equals(nomEquip)) {
                                System.out.println("");
                                Puntuacions[i][2] = teclat.nextInt();
                                Puntuacions[i][5] = (Puntuacions[i][2] * 3 + Puntuacions[i][3] * 1);
                                Puntuacions[i][1] = (Puntuacions[i][2] + Puntuacions[i][3] + Puntuacions[i][4]);
                                System.out.println("Equip: " + Equips[y] +  Puntuacions[i][2] + Puntuacions[i][5] + Puntuacions[i][1]);
                                break;
                            }
                        case 5:
                            if (equips[x].equals(nomEquip)) {
                                System.out.println("");
                                Puntuacions[i][3] = teclat.nextInt();
                                Puntuacions[i][5] = (Puntuacions[i][2] * 3 + Puntuacions[i][3] * 1);
                                Puntuacions[i][1] = (Puntuacions[i][2] + Puntuacions[i][3] + Puntuacions[i][4]);
                                break;
                            }
                        case 6:
                            if (equips[x].equals(nomEquip)) {
                                System.out.println("");
                                Puntuacions[i][4] = teclat.nextInt();
                                Puntuacions[i][5] = (Puntuacions[i][2] * 3 + Puntuacions[i][3] * 1);
                                Puntuacions[i][1] = (Puntuacions[i][2] + Puntuacions[i][3] + Puntuacions[i][4]);
                                break;
                            }
                        case 7:
                            x += 6;
                            exit = true;
                            break;
                        default:
                            System.out.println("Opció incorrecta.");
                    }
                } while (!exit);
            }
        }
    }

}